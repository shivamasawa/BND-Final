import unittest
import time
import test_mobile_core

WEB_SITE = "https://www.businessnewsdaily.com/"

class OfferLogicTestCase(test_mobile_core.MobileTestCore):
   
    @classmethod
    def setUpClass(cls):
        super(OfferLogicTestCase, cls).setUpClass()
        driver = test_mobile_core.MobileTestCore.driver
    
    def testOfferLogic(self):  
        print("================ Offer Logic Tests ================")
        errors = []
        #testBusinessLoans
        try:
            url = WEB_SITE+'8448-best-business-loans.html'
            self.driver.get(url)
            offers = self.driver.find_elements_by_css_selector("div[id^='olcontent-grid'] div.aac-offer")
            num_offers = len(offers)
            try:
                self.assertEquals(num_offers, 4, "Expected 4 offers but found "+str(num_offers))
            except:
                time.sleep(2)
                offers = self.driver.find_elements_by_css_selector("div[id^='olcontent-grid'] div.aac-offer")
                self.assertEquals(num_offers, 4, "Expected 4 offers but found "+str(num_offers))
                num_offers = len(offers)
            for offer in offers:
                self.assertTrue(offer.is_displayed(), "At least 1 offer is not displayed")
            print("testBusinessLoans: pass")
        except Exception as err:
            print("testBusinessLoans: FAIL")
            print("Error URL: "+self.driver.current_url)
            print(err)
            errors.append(err)
        print("---------------------------------------------------")
        
        #testSquareReview
        try:
            url = WEB_SITE+'8064-best-mobile-credit-card-processor.html'
            print(url)
            self.driver.get(url)
            offer1 = self.driver.find_element_by_css_selector('div#olcontent-banner-1 div.aac-offer')
            self.assertTrue(offer1.is_displayed(), "Header offer is not displayed")
            offer2 = self.driver.find_element_by_css_selector('div#olcontent-howtobuy-1 div.aac-offer')
            self.assertTrue(offer2.is_displayed(), "Content offer is not displayed")
            print("testAquareReview: pass")
        except Exception as err:
            print("testSquareReview: FAIL")
            print("Error URL: "+self.driver.current_url)
            print(err)
            errors.append(err)
        print("---------------------------------------------------")
        if(len(errors) > 0):
            print("Total Failures/Errors: "+str(len(errors)))
            print("===================================================")
            raise errors[0]
        
if __name__ == "__main__":
    suite = unittest.TestLoader().loadTestsFromTestCase(OfferLogicTestCase)
    unittest.TextTestRunner().run(suite) 